package fr.adavis.locavek;

import java.awt.Container;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VueAccueil extends JPanel {

	private static final long serialVersionUID = 1L;

	public VueAccueil() {
		super();
		this.creerInterfaceUtilisateur();
	}
	
	private void creerInterfaceUtilisateur() {
		Box boxPrincipale = Box.createVerticalBox() ;
		boxPrincipale.add(new JLabel("Accueil")) ;
		
		this.add(boxPrincipale) ;
	}

	
	
	
	
}
