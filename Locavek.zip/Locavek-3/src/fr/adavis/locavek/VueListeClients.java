package fr.adavis.locavek;

import java.awt.CardLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VueListeClients extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private JTable tabClients;
	private ModeleListeClients modeleClients ;

	public VueListeClients() {
		super();
		this.creerInterfaceUtilisateur();
	}
	
	private void creerInterfaceUtilisateur() {
		Box boxPrincipale = Box.createVerticalBox() ;
		boxPrincipale.add(new JLabel("Liste des Clients")) ;
		
		modeleClients = new ModeleListeClients() ;
		this.tabClients = new JTable(modeleClients) ;
		this.tabClients.setRowHeight(30) ;
		JScrollPane spClients = new JScrollPane(this.tabClients) ;
		spClients.setPreferredSize(new Dimension(1090,420)) ;
		boxPrincipale.add(spClients) ;
		
		this.add(boxPrincipale) ;
	}

	public JTable getTabClients() {
		return tabClients;
	}

	public ModeleListeClients getModeleClients() {
		return modeleClients;
	}

	
	
}
