package fr.adavis.locavek;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Vue relative au cas d'utilisation "Enregistrer une nouvelle location"
 * 
 * @author xilim
 *
 */
public class VueNouvelleLocation extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private ControleurNouvelleLocation controleur ;
	
	// Votre code ici
	private ModeleLocavek modele = ModeleLocavek.getModele() ;
	
	private JComboBox<Client> cbClients = new JComboBox<Client>() ;
	private JComboBox<Vehicule> cbVehicules = new JComboBox<Vehicule>() ;
	
	private JTextField tfDateRetourPrevue = new JTextField() ;
	
	private JButton bEnregistrer = new JButton("Enregistrer") ;
	private JButton bAnnuler = new JButton("Annuler") ;
	
	/** Constructeur
	 * @param vueParente La vue principale de l'application
	 */
	public VueNouvelleLocation(JFrame vueParente) {
		super(vueParente,"Nouvelle location",true);
		System.out.println("VueNouvelleLocation::VueNouvelleLocation()") ;
		this.creerInterfaceUtilisateur() ;
		this.controleur = new ControleurNouvelleLocation(this) ;
		this.initialiser();
		this.pack();
		this.setLocationRelativeTo(vueParente) ;
		this.setResizable(false) ;
		this.setVisible(true) ;
	}

	public JComboBox<Client> getCbClients() {
		return cbClients;
	}
	
	public JComboBox<Vehicule> getCbVehicules() {
		return cbVehicules;
	}

	public JTextField getTfDateRetourPrevue() {
		return tfDateRetourPrevue;
	}

	public JButton getbEnregistrer() {
		return bEnregistrer;
	}

	public JButton getbAnnuler() {
		return bAnnuler;
	}

	/** Créer l'interface utilisateur
	 * 
	 */
	private void creerInterfaceUtilisateur(){
		System.out.println("VueNouvelleLocation::creerInterfaceUtilisateur()") ;
		
		// Votre code ici
		
		
		
		Container conteneur = this.getContentPane() ;
		
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxChamps = Box.createHorizontalBox() ;
		Box boxSaisies = Box.createVerticalBox() ;
		Box boxEtiquettes = Box.createVerticalBox() ;
		Box boxLigne = Box.createHorizontalBox() ;
		Box boxActions = Box.createHorizontalBox() ;
		
		boxEtiquettes.add(new JLabel("Client : ")) ;
		boxEtiquettes.add(new JLabel("Vehicule : ")) ;
		boxEtiquettes.add(new JLabel("Date de retour prévue : ")) ;
		
		boxSaisies.add(this.cbClients) ;
		boxSaisies.add(this.cbVehicules) ;
		boxSaisies.add(this.tfDateRetourPrevue) ;
		
		boxLigne.add(Box.createHorizontalStrut(5)) ;
		boxLigne.add(new JSeparator()) ;
		boxLigne.add(Box.createHorizontalStrut(5)) ;
		
		boxActions.add(Box.createHorizontalStrut(5)) ;
		boxActions.add(this.bEnregistrer) ;
		boxActions.add(Box.createHorizontalStrut(5)) ;
		boxActions.add(this.bAnnuler) ;
		boxActions.add(Box.createHorizontalStrut(5)) ;
		
		boxChamps.add(Box.createHorizontalStrut(5)) ;
		boxChamps.add(boxEtiquettes) ;
		boxChamps.add(Box.createHorizontalStrut(5)) ;
		boxChamps.add(boxSaisies) ;
		boxChamps.add(Box.createHorizontalStrut(5)) ;
		
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		boxPrincipale.add(boxChamps) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		boxPrincipale.add(boxLigne) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		boxPrincipale.add(boxActions) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		
		conteneur.add(boxPrincipale) ;
		
		Dimension dimensionBouton = this.bEnregistrer.getPreferredSize() ;
		
		this.bAnnuler.setPreferredSize(dimensionBouton) ;
		this.bAnnuler.setMaximumSize(dimensionBouton) ;
		this.bAnnuler.setMinimumSize(dimensionBouton) ;		
		
	}
	
	
	/** Initialiser les champs (liste des clients, liste des véhicules et date de retour prévue
	 * 
	 */
	public void initialiser(){
		System.out.println("VueNouvelleLocation::initialiser()") ;
		
		// Votre code ici
		
		this.cbClients.removeAllItems() ;
		this.cbVehicules.removeAllItems() ;
		
		List<Client> clients = this.modele.getClients() ;
		for(Client unClient : clients) {
			this.cbClients.addItem(unClient) ;
		}
		
		List<Vehicule> vehicules = this.modele.getVehiculesDisponibles() ;
		for(Vehicule unVehicule : vehicules) {
			this.cbVehicules.addItem(unVehicule) ;
		}
		
		DateFR date = new DateFR() ;
		System.out.println(date) ;
		this.tfDateRetourPrevue.setText(date.toString());
		
	}
}
