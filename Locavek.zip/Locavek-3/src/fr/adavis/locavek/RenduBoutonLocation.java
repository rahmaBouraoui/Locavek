package fr.adavis.locavek;

import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.text.JTextComponent;

public class RenduBoutonLocation extends JButton implements TableCellRenderer{
	
	
	@Override
	public Component getTableCellRendererComponent(JTable table, Object value,
		boolean isSelected, boolean hasFocus, int row, int column) {
				
		boolean enCours = ModeleLocavek.getModele().getLocations().get(row).estEnCours() ;
		
		if(enCours == true) {
			this.setEnabled(true) ;
		}
		else {
			this.setEnabled(false) ;
		}
		
		this.setText("Enregistrer") ;
		
		return this ;
	}



}
