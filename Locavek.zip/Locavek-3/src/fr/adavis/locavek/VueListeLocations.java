package fr.adavis.locavek;
import java.awt.CardLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VueListeLocations extends JPanel {
	private static final long serialVersionUID = 1L;
	private JTable tabLocations;
	private ModeleListeLocations modeleLocations ;

	public VueListeLocations() {
		super();
		this.creerInterfaceUtilisateur();
	}
	
	private void creerInterfaceUtilisateur() {
		Box boxPrincipale = Box.createVerticalBox() ;
		boxPrincipale.add(new JLabel("Liste des Locations")) ;
		
		modeleLocations = new ModeleListeLocations() ;
		this.tabLocations = new JTable(modeleLocations) ;
		this.appliquerRendu(); 
		
		
		
		this.tabLocations.setRowHeight(30) ;
		JScrollPane spLocations = new JScrollPane(this.tabLocations) ;
		spLocations.setPreferredSize(new Dimension(1090,420)) ;
		boxPrincipale.add(spLocations) ;
		
		this.add(boxPrincipale) ;
	}
	
	public JTable getTabLocations() {
		return tabLocations;
	}

	public ModeleListeLocations getModeleLocations() {
		return this.modeleLocations ;
	}
	
	public void appliquerRendu() {
		RenduCelluleLocation rendu = new RenduCelluleLocation() ;
//		tabLocations.setDefaultRenderer(Object.class, rendu);
		this.tabLocations.getColumn("Numéro").setCellRenderer(rendu) ;
		this.tabLocations.getColumn("Date de départ").setCellRenderer(rendu) ;
		this.tabLocations.getColumn("Date de retour effectif").setCellRenderer(rendu) ;
		this.tabLocations.getColumn("Client").setCellRenderer(rendu) ;
		this.tabLocations.getColumn("Véhicule").setCellRenderer(rendu) ;
		
		RenduBoutonLocation rendu1 = new RenduBoutonLocation() ;
		this.tabLocations.getColumn("Retour").setCellRenderer(rendu1) ;
	}
	
	
}
