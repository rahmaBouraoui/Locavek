package fr.adavis.locavek;

import java.util.List;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

public class ModeleListeLocations extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	
	private List<Location> locations = ModeleLocavek.getModele().getLocations() ;
	private final String[] entetes = {"Numéro","Date de départ","Date de retour effectif", "Client", "Véhicule", "Retour"} ;
	
	public ModeleListeLocations() {
		super() ;
		System.out.println("ModeleListeLocations::ModeleListeLocations()") ;
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeLocations::getRowCount()") ;
		return false ;
	}
	
	@Override
	public Class getColumnClass(int columnIndex) {
		System.out.println("ModeleListeLocations::getColumnName()") ;
		switch(columnIndex) {
			case 0 : 
				return Integer.class ;
			case 1 : 
				return DateFR.class ;
			case 2 : 
				return DateFR.class ;
			case 3 :
				return String.class ;
			case 4 :
				return String.class ;
			case 5 :
				return JButton.class ;
			default : 
				return null ;
				
		}
		
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeLocations::getValueAt("+rowIndex+","+columnIndex+")") ;
		
		switch(columnIndex) {
			case 0 : 
				return  new Integer(locations.get(rowIndex).getNumero()) ;
			case 1 : 
				return locations.get(rowIndex).getDateDepart() ;
			case 2 : 
				return locations.get(rowIndex).getDateRetourEffective() ;
			case 3 :
				return locations.get(rowIndex).getClient().getNom() + " " + locations.get(rowIndex).getClient().getPrenom() ;
			case 4 :
				return locations.get(rowIndex).getVehicule().getImmatriculation() ;
			default : 
				return null ;
					
		}
	

	}
	
	public void actualiser(){
		System.out.println("ModeleListeVehicules::actualiser()") ;
		this.fireTableDataChanged();
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return locations.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return entetes.length ;
	}

	@Override
	public String getColumnName(int columnIndex) {
		// TODO Auto-generated method stub
		return entetes[columnIndex] ;
	}
	
	
}
