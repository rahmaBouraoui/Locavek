package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ControleurBoutonLocationEnregistrer implements ActionListener {
	
	private RenduBoutonLocation rendu ;
	
	JTextField tfSaisirKm = new JTextField(20) ;

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurBoutonLocationEnregistrer::actionPerformed()") ;
		Object sourceEvt = e.getSource() ;
		if(sourceEvt == this.rendu ) {
			String km = getTfSaisirKm().getText() ;
			JOptionPane.showMessageDialog(rendu, "Saisir la valeur du compteur kilométrique" + "\n" + km , "Retour Véhicule", JOptionPane.OK_CANCEL_OPTION);
		}
		
	}
	
	private void enregistrerEcouteur(){
		System.out.println("ControleurBoutonLocationEnregistrer::enregistrerEcouteur()") ;
		this.rendu.addActionListener(this) ;
	}

	public JTextField getTfSaisirKm() {
		return tfSaisirKm;
	}
	
	
}
