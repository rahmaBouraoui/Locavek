package fr.adavis.locavek;

import java.util.List;

import javax.swing.table.AbstractTableModel;

public class ModeleListeClients extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	
	private List<Client> clients = ModeleLocavek.getModele().getClients() ;
	private final String[] entetes = {"Numéro","Nom","Prénom","Mobile"} ;
	
	public ModeleListeClients() {
		super() ;
		System.out.println("ModeleListeClients::ModeleListeClients()") ;
	}

	
	@Override
	public int getRowCount() {
		System.out.println("ModeleListeClients::getRowCount()") ;
		// Votre code ici
		return this.clients.size() ;
	}

	@Override
	public int getColumnCount() {
		System.out.println("ModeleListeClients::getColumnCount()") ;
		// Votre code ici
		return this.entetes.length ;
	}
	
	@Override
	public String getColumnName(int columnIndex) {
		System.out.println("ModeleListeClients::getColumnName()") ;
		// Votre code ici
		return this.entetes[columnIndex] ;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeClients::getValueAt("+rowIndex+","+columnIndex+")") ;
		// Votre code ici
		
		switch(columnIndex) {
			case 0 :
				return new Integer(this.clients.get(rowIndex).getNumero()) ;
			case 1 : 
				return this.clients.get(rowIndex).getNom() ;
			case 2 :
				return this.clients.get(rowIndex).getPrenom() ;
			case 3 :
				return this.clients.get(rowIndex).getMobile() ;
			default :
				return null ;
		}
		
	}
	
	public void actualiser(){
		System.out.println("ModeleListeClients::actualiser()") ;
		this.fireTableDataChanged();
	}

}
