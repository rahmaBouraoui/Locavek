package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.* ;

import javax.naming.OperationNotSupportedException;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/** Contrôleur associé à la vue principale de l'application
 * @author xilim
 *
 */
public class ControleurLocavek implements ActionListener {

	private VueLocavek vue ;
	
	/** Constructeur
	 * @param vue La vue principale de l'application
	 */
	public ControleurLocavek(VueLocavek vue) {
		super();
		System.out.println("ControleurLocavek::ControleurLocavek()") ;
		this.vue = vue ;
		this.enregistrerEcouteur();
	}
	
	public VueLocavek getVuePrincipale() {
		return this.vue ;
	}

	public void setVuePrincipales(VueLocavek vue) {
		this.vue = vue ;
	}
	
	/** Enregistrer le contrôleur comme écouteur des items de menu
	 * 
	 */
	private void enregistrerEcouteur(){
		System.out.println("ControleurLocavek::enregistrerEcouteur()") ;
		// Votre code ici
		this.vue.getItemQuitter().addActionListener(this) ;
		this.vue.getItemConnecter().addActionListener(this) ;
		this.vue.getItemDeconnecter().addActionListener(this) ;
		this.vue.getItemEnregistrerClient().addActionListener(this) ;
		this.vue.getItemEnregistrerLocation().addActionListener(this) ;
		this.vue.getItemVisualiserClients().addActionListener(this) ;
		this.vue.getItemVisualiserVehicules().addActionListener(this) ;
		this.vue.getItemVisualiserLocations().addActionListener(this) ;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurLocavek::actionPerformed()") ;
		Object sourceEvt = e.getSource() ;
		if(sourceEvt == this.vue.getItemQuitter()) {
			int rep = JOptionPane.showConfirmDialog(this.vue, "Voulez-vous vraiment quitter l'application ? ", "Quitter", JOptionPane.YES_NO_OPTION) ;
			if(rep == JOptionPane.YES_OPTION) {
				System.exit(0) ;
			}
		}
		
		else if(sourceEvt == this.vue.getItemConnecter()) {
			VueAuthentification vueAuth = new VueAuthentification(this.vue) ;
			if(vueAuth.getEtatTentativeConnexion() == EtatTentativeConnexion.OK) {
				this.vue.setMenusConnecte();
			}
		}
		
		else if(sourceEvt == this.vue.getItemDeconnecter()) {
			int rep = JOptionPane.showConfirmDialog(this.vue, "Voulez-vous vraiment vous déconnecter ? ", "Déconnexion", JOptionPane.YES_NO_OPTION) ;
			if(rep == JOptionPane.YES_OPTION) {
				this.vue.setMenusDeconnecte() ;
			}
		}
		else if(sourceEvt == this.vue.getItemEnregistrerClient()) {
			VueNouveauClient vueNvC = new VueNouveauClient(this.vue) ;
			this.vue.getVueListeClients().getModeleClients().actualiser();
		}
		
		else if(sourceEvt == this.vue.getItemEnregistrerLocation()) {
			VueNouvelleLocation vueNvL = new VueNouvelleLocation(this.vue) ;
			this.vue.getVueListeVehicules().getModeleVehicules().actualiser();
		}
		else if(sourceEvt == this.vue.getItemVisualiserClients()) {
			this.vue.changerVue("ListeClients");
		}
		else if(sourceEvt == this.vue.getItemVisualiserVehicules()) {
			this.vue.changerVue("ListeVehicules");
		}
		else if(sourceEvt == this.vue.getItemVisualiserLocations()) {
			this.vue.changerVue("ListeLocations");
		}
	}
		
	
}
