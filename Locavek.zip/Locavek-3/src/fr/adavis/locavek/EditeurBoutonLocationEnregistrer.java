package fr.adavis.locavek;

import java.awt.Component;

public class EditeurBoutonLocationEnregistrer {
	
	private ControleurBoutonLocationEnregistrer controleur ;
	private boolean isPushed ;

	public EditeurBoutonLocationEnregistrer() {
		super();
	}
	
	public Component getTableCellEditorComponent() {
		
	}

}
