package fr.adavis.locavek;

import java.awt.CardLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

	public class VueListeVehicule extends JPanel {
		
		private static final long serialVersionUID = 1L;
		private JTable tabVehicules;
		private ModeleListeVehicules modeleVehicules ;

		public VueListeVehicule() {
			super();
			this.creerInterfaceUtilisateur();
		}
		
		private void creerInterfaceUtilisateur() {
			Box boxPrincipale = Box.createVerticalBox() ;
			boxPrincipale.add(new JLabel("Liste des Véhicules")) ;
			
			modeleVehicules = new ModeleListeVehicules() ;
			this.tabVehicules = new JTable(modeleVehicules) ;
			
			RenduCelluleVehicule rendu = new RenduCelluleVehicule() ;
			tabVehicules.setDefaultRenderer(Object.class, rendu);
			
			
			this.tabVehicules.setRowHeight(30) ;
			JScrollPane spVehicules = new JScrollPane(this.tabVehicules) ;
			spVehicules.setPreferredSize(new Dimension(1090,420)) ;
			boxPrincipale.add(spVehicules) ;
			
			this.add(boxPrincipale) ;
		}
		
		public JTable getTabVehicules() {
			return tabVehicules;
		}

		public ModeleListeVehicules getModeleVehicules() {
			return modeleVehicules;
		}
		
		

	}

	

